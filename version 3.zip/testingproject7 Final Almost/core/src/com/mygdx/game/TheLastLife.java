package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.mygdx.game.coins.drawCoins.drawingCoinsOnMaze;
import com.mygdx.game.coins.pointsOnMazeForCoins.FrightenedModeCoinPoints;
import com.mygdx.game.coins.pointsOnMazeForCoins.LegalButNoCoinPoints;
import com.mygdx.game.coins.pointsOnMazeForCoins.LegalPoints;
import com.mygdx.game.extra.playerDirectionCommandStore.PlayerDirectionCommandStore;
import com.mygdx.game.monsterModes.decidingModesForAllMonsters.DecidingModesForAllMonsters;
import com.mygdx.game.movementActivityOfPlayerAndMonsters.MovementActivityOfPlayerAndMonsters;
import com.mygdx.game.playerMonsterCollision.PlayerMonsterCollision;

import javax.swing.plaf.TextUI;
import java.awt.*;

public class TheLastLife extends ApplicationAdapter implements InputProcessor {


	public static float timeState=0f;



	public static float cellWidth = 36;
	public static float cellHeight = 30;



	//Pacman all variables
	public static boolean arcRight = false,arcLeft=false,arcUp=false,arcDown=false;
	public static boolean arcMovementOn = false;
	public static float arcX = (14*cellWidth)+ (cellWidth/2),arcY = 8*cellHeight;


	public static float arcXMax = 1044-72,arcXMin = 72, arcYMax = 960-60, arcYMin = arcYMin = 60;
	public static float arcRadius = 10;
	public static float arcMove = 2;

	public static char arcDirection ='0';

	public static boolean playerMovementOn = false;


	public static float[][] coins = LegalPoints.returnLegalPoints();
	public static float[][] noCoinLegalPoints = LegalButNoCoinPoints.returnLegalButNoCoinPoints();
	public static float[][] noteEatenCoins = new float[30][32];
	public static ShapeRenderer shapeRenderer;


	public static SpriteBatch batch;
	public static Texture img;


	//* ALl monster*//
	public static long modeChangeTimeInterval = 30;
	//RED GHOST//
	public static float redGhostXInitial = (14*cellWidth)+(cellWidth)/2,redGhostYInitial=(20*cellHeight);
	public static float redGhostX=redGhostXInitial,redGhostY=redGhostYInitial;

	public static float redGhostScatterX = 29*36;
	public static float redGhostScatterY = 32*30;

	public static boolean redGhostEatenMode = false;
	public static boolean redGhostScatterModeOn = true;
	public static boolean redGhostChaseModeOn = false;

	public static long timeElapsedForPauseToMovementRedMonster = 0;
	public static long timeElapsedForModeChangeRedMonster = 0;



	public static float redGhostRadius = 10;
	public static float redGhostMove= 2;
	public static boolean redGhostMovementOn = false;
	public static boolean redRight=false,redLeft=false,redUp=false,redDown=false;




	// ajke

	public static float[][] coinForFrightenedMode = FrightenedModeCoinPoints.returnFrightenedCoin();
	public static boolean redGhostFrightenedModeOn = false;
	public static long timeDurationOfGhostFrightenedModeRedMonster = 0;
	public static boolean directionChangedOnFrightenedModeRed = false;
	public static boolean isDirectionChangedOnEatenModeRed = false;
	public static boolean redGhostSpeedIncreasedAfterEaten = false;
	public static long increasedRedGhostSpeedAtEatenMode = 6;
	public static float redGhostMoveInitial = redGhostMove;



	//for pinkMonster

	public static float pinkGhostXInitial = (14*cellWidth)+(cellWidth)/2,pinkGhostYInitial=(20*cellHeight)-(3*cellHeight);
	public static float pinkGhostX=pinkGhostXInitial,pinkGhostY=pinkGhostYInitial;

	public static float pinkGhostScatterX = 0;
	public static float pinkGhostScatterY = 32*30;

	public static boolean pinkGhostEatenMode = false;
	public static boolean pinkGhostScatterModeOn = false;
	public static boolean pinkGhostChaseModeOn = false;
	public static boolean pinkGhostFrightenedModeOn = false;

	public static long timeElapsedForPauseToMovementPinkMonster = 0;
	public static long timeElapsedForModeChangePinkMonster = 0;



	public static float pinkGhostRadius = 10;
	public static float pinkGhostMove= 2;
	public static boolean pinkGhostMovementOn = false;
	public static boolean pinkRight=false,pinkLeft=false,pinkUp=false,pinkDown=false;



	public static long timeDurationOfGhostFrightenedModePinkMonster = 0;
	public static boolean directionChangedOnFrightenedModePink = false;
	public static boolean isDirectionChangedOnEatenModePink = false;
	public static boolean pinkGhostSpeedIncreasedAfterEaten = false;
	public static long increasedPinkGhostSpeedAtEatenMode = 6;

	public static float pinkGhostMoveInitial = redGhostMove;


   public static boolean pinkGhostOutOfGhostHouse = false;
   public static boolean pinkGhostReachedOutOfGhostHouseEatenMode = false;




   // forCyanMonster
    public static float cyanGhostXInitial = (13*cellWidth),cyanGhostYInitial=(20*cellHeight)-(3*cellHeight);
	public static float cyanGhostX=cyanGhostXInitial,cyanGhostY=cyanGhostYInitial;

	public static float cyanGhostScatterX = 0;
	public static float cyanGhostScatterY = 0;

	public static boolean cyanGhostEatenMode = false;
	public static boolean cyanGhostScatterModeOn = false;
	public static boolean cyanGhostChaseModeOn = false;
	public static boolean cyanGhostFrightenedModeOn = false;

	public static long timeElapsedForPauseToMovementCyanMonster = 0;
	public static long timeElapsedForModeChangeCyanMonster = 0;



	public static float cyanGhostRadius = 10;
	public static float cyanGhostMove= 2;
	public static boolean cyanGhostMovementOn = false;
	public static boolean cyanRight=false,cyanLeft=false,cyanUp=false,cyanDown=false;



	public static long timeDurationOfGhostFrightenedModeCyanMonster = 0;
	public static boolean directionChangedOnFrightenedModeCyan = false;
	public static boolean isDirectionChangedOnEatenModeCyan = false;
	public static boolean cyanGhostSpeedIncreasedAfterEaten = false;
	public static long increasedCyanGhostSpeedAtEatenMode = 6;

	public static float cyanGhostMoveInitial = redGhostMove;


	public static boolean cyanGhostOutOfGhostHouse = false;
	public static boolean cyanGhostCenterOfGhostHouse = false;
	public static boolean cyanGhostReachedOutOfGhostHouseEatenMode = false;
	public static boolean cyanGhostReachedCenterOfGhostHouseEatenMode = false;




	//29-4-2022

	//red

	public static SpriteBatch batchRed;
	public static Texture redMonsterRight,redMonsterLeft;
	public static boolean isRedRightPng = true;
	public static boolean isRedLeftPng = false;
	public static float redWidthPng = 45;
	public static float redHeightPng = 54;


	public static SpriteBatch batchRedFri;
	public static Texture redMonsterRightFri,redMonsterLeftFri;
	public static boolean isRedRightPngFri = true;
	public static boolean isRedLeftPngFri = false;


	public static SpriteBatch batchRedEaten;
	public static Texture redMonsterRightEaten,redMonsterLeftEaten;
	public static boolean isRedRightPngEaten = true;
	public static boolean isRedLeftPngEaten = false;
	public static float redWidthPngEaten = 38;
	public static float redHeightPngEaten = 43;



	public static SpriteBatch batchPink;
	public static Texture pinkMonsterRight,pinkMonsterLeft;
	public static boolean isPinkRightPng = true;
	public static boolean isPinkLeftPng = false;
	public static float pinkWidthPng = 45;
	public static float pinkHeightPng = 54;


	public static SpriteBatch batchPinkFri;
	public static Texture pinkMonsterRightFri,pinkMonsterLeftFri;
	public static boolean isPinkRightPngFri = true;
	public static boolean isPinkLeftPngFri = false;


	public static SpriteBatch batchPinkEaten;
	public static Texture pinkMonsterRightEaten,pinkMonsterLeftEaten;
	public static boolean isPinkRightPngEaten = true;
	public static boolean isPinkLeftPngEaten = false;
	public static float pinkWidthPngEaten = 38;
	public static float pinkHeightPngEaten = 43;



	public static SpriteBatch batchCyan;
	public static Texture cyanMonsterRight,cyanMonsterLeft;
	public static boolean isCyanRightPng = true;
	public static boolean isCyanLeftPng = false;
	public static float cyanWidthPng = 45;
	public static float cyanHeightPng = 54;


	public static SpriteBatch batchCyanFri;
	public static Texture cyanMonsterRightFri,cyanMonsterLeftFri;
	public static boolean isCyanRightPngFri = true;
	public static boolean isCyanLeftPngFri = false;


	public static SpriteBatch batchCyanEaten;
	public static Texture cyanMonsterRightEaten,cyanMonsterLeftEaten;
	public static boolean isCyanRightPngEaten = true;
	public static boolean isCyanLeftPngEaten = false;
	public static float cyanWidthPngEaten = 38;
	public static float cyanHeightPngEaten = 43;


    //orange
	public static SpriteBatch batchOrange;
	public static Texture orangeMonsterRight,orangeMonsterLeft;
	public static boolean isOrangeRightPng = true;
	public static boolean isOrangeLeftPng = false;
	public static float orangeWidthPng = 45;
	public static float orangeHeightPng = 54;


	public static SpriteBatch batchOrangeFri;
	public static Texture orangeMonsterRightFri,orangeMonsterLeftFri;
	public static boolean isOrangeRightPngFri = true;
	public static boolean isOrangeLeftPngFri = false;


	public static SpriteBatch batchOrangeEaten;
	public static Texture orangeMonsterRightEaten,orangeMonsterLeftEaten;
	public static boolean isOrangeRightPngEaten = true;
	public static boolean isOrangeLeftPngEaten = false;
	public static float orangeWidthPngEaten = 38;
	public static float orangeHeightPngEaten = 43;



	public static float orangeGhostXInitial = (16*cellWidth),orangeGhostYInitial=(20*cellHeight)-(3*cellHeight);
	public static float orangeGhostX=orangeGhostXInitial,orangeGhostY=orangeGhostYInitial;

	public static float orangeGhostScatterX = 29*cellWidth;
	public static float orangeGhostScatterY = 0;

	public static boolean orangeGhostEatenMode = false;
	public static boolean orangeGhostScatterModeOn = false;
	public static boolean orangeGhostChaseModeOn = false;
	public static boolean orangeGhostFrightenedModeOn = false;

	public static long timeElapsedForPauseToMovementOrangeMonster = 0;
	public static long timeElapsedForModeChangeOrangeMonster = 0;



	public static float orangeGhostRadius = 10;
	public static float orangeGhostMove= 2;
	public static boolean orangeGhostMovementOn = false;
	public static boolean orangeRight=false,orangeLeft=false,orangeUp=false,orangeDown=false;



	public static long timeDurationOfGhostFrightenedModeOrangeMonster = 0;
	public static boolean directionChangedOnFrightenedModeOrange = false;
	public static boolean isDirectionChangedOnEatenModeOrange = false;
	public static boolean orangeGhostSpeedIncreasedAfterEaten = false;
	public static long increasedOrangeGhostSpeedAtEatenMode = 6;

	public static float orangeGhostMoveInitial = redGhostMove;


	public static boolean orangeGhostOutOfGhostHouse = false;
	public static boolean orangeGhostCenterOfGhostHouse = false;
	public static boolean orangeGhostReachedOutOfGhostHouseEatenMode = false;
	public static boolean orangeGhostReachedCenterOfGhostHouseEatenMode = false;


	//for cyan monster


	public static SpriteBatch batchPlayer;
	public static Texture playerMonsterRight,playerMonsterLeft;
	public static boolean isPlayerRightPng = true;
	public static boolean isPlayerLeftPng = false;
	public static float playerWidthPng = 28;
	public static float playerHeightPng = 37;




	Music music;
	public static Texture texture,textureBig;
    public static Sprite sprite,spriteBig;

	@Override
	public void create () {



		batch = new SpriteBatch();
		img = new Texture("mugdha4.png");

		batchRed = new SpriteBatch();
		redMonsterRight = new Texture("red/redRight.png");
		redMonsterLeft = new Texture("red/redLeft.png");

		batchRedFri = new SpriteBatch();
		redMonsterRightFri = new Texture("fri/friRightt.png");
		redMonsterLeftFri = new Texture("fri/friLeftt.png");

		batchRedEaten = new SpriteBatch();
		redMonsterRightEaten = new Texture("eaten/eatenRight.png");
		redMonsterLeftEaten = new Texture("eaten/eatenLeft.png");



		batchPink = new SpriteBatch();
		pinkMonsterRight = new Texture("pink/pinkRight.png");
		pinkMonsterLeft = new Texture("pink/pinkLeft.png");

		batchPinkFri = new SpriteBatch();
		pinkMonsterRightFri = new Texture("fri/friRightt.png");
		pinkMonsterLeftFri = new Texture("fri/friLeftt.png");

		batchPinkEaten = new SpriteBatch();
		pinkMonsterRightEaten = new Texture("eaten/eatenRight.png");
		pinkMonsterLeftEaten = new Texture("eaten/eatenLeft.png");


		batchCyan = new SpriteBatch();
		cyanMonsterRight = new Texture("cyan/cyanRight.png");
		cyanMonsterLeft = new Texture("cyan/cyanLeft.png");

		batchCyanFri = new SpriteBatch();
		cyanMonsterRightFri = new Texture("fri/friRightt.png");
		cyanMonsterLeftFri = new Texture("fri/friLeftt.png");

		batchCyanEaten = new SpriteBatch();
		cyanMonsterRightEaten = new Texture("eaten/eatenRight.png");
		cyanMonsterLeftEaten = new Texture("eaten/eatenLeft.png");



		batchOrange = new SpriteBatch();
		orangeMonsterRight = new Texture("orange/orangeRight.png");
		orangeMonsterLeft = new Texture("orange/orangeLeft.png");

		batchOrangeFri = new SpriteBatch();
		orangeMonsterRightFri = new Texture("fri/friRightt.png");
		orangeMonsterLeftFri = new Texture("fri/friLeftt.png");

		batchOrangeEaten = new SpriteBatch();
		orangeMonsterRightEaten = new Texture("eaten/eatenRight.png");
		orangeMonsterLeftEaten = new Texture("eaten/eatenLeft.png");



		batchPlayer = new SpriteBatch();
		playerMonsterRight = new Texture("player/playerRight.png");
		playerMonsterLeft = new Texture("player/playerLeft.png");


       music = Gdx.audio.newMusic(Gdx.files.internal("music/amongus.ogg"));
	   music.setLooping(true);
	   music.setVolume(0.3f);
	   music.play();


		texture = new Texture("coins/coins6.png");
		sprite = new Sprite(texture,15,15);
		sprite.setOrigin(15/2,15/2);

		textureBig = new Texture("coins/coins4.png");
		spriteBig = new Sprite(textureBig,20,20);
		spriteBig.setOrigin(20/2,20/2);

		shapeRenderer = new ShapeRenderer();
		for(int i=0;i<30;i++)
		{
			for(int j=0;j<32;j++){
				if(coins[i][j]==1) noteEatenCoins[i][j]=1;
			}
		}



	}

	@Override
	public void render () {
		Gdx.input.setInputProcessor((InputProcessor) this);

		System.out.println(cyanGhostScatterModeOn + "  " + cyanGhostChaseModeOn +"   "+cyanRight+cyanLeft+cyanUp+cyanDown);

		timeState += Gdx.graphics.getDeltaTime();

		if(timeState>=1f){
			timeState=0f;

			// forRed
			timeElapsedForPauseToMovementRedMonster++;
			if(playerMovementOn && redGhostFrightenedModeOn==false && redGhostEatenMode ==false)timeElapsedForModeChangeRedMonster++;
			if(redGhostFrightenedModeOn) timeDurationOfGhostFrightenedModeRedMonster++;

			//forPink
			timeElapsedForPauseToMovementPinkMonster++;
			if(playerMovementOn && pinkGhostFrightenedModeOn==false && pinkGhostEatenMode ==false)timeElapsedForModeChangePinkMonster++;
			if(pinkGhostFrightenedModeOn) timeDurationOfGhostFrightenedModePinkMonster++;

			//forCyan
			timeElapsedForPauseToMovementCyanMonster++;
			if(playerMovementOn && cyanGhostFrightenedModeOn==false && cyanGhostEatenMode ==false)timeElapsedForModeChangeCyanMonster++;
			if(cyanGhostFrightenedModeOn) timeDurationOfGhostFrightenedModeCyanMonster++;


			//forOrange
			timeElapsedForPauseToMovementOrangeMonster++;
			if(playerMovementOn && orangeGhostFrightenedModeOn==false && orangeGhostEatenMode ==false)timeElapsedForModeChangeOrangeMonster++;
			if(orangeGhostFrightenedModeOn) timeDurationOfGhostFrightenedModeOrangeMonster++;





		}

		//Background bg = new Background();
		batch.begin();
		batch.draw(img,0,0);
		batch.end();


		drawingCoinsOnMaze drawingCoinsOnMaze = new drawingCoinsOnMaze();
		MovementActivityOfPlayerAndMonsters movementActivityOfPlayerAndMonsters = new MovementActivityOfPlayerAndMonsters();
		DecidingModesForAllMonsters decidingModesForAllMonsters = new DecidingModesForAllMonsters();
		PlayerMonsterCollision playerMonsterCollision = new PlayerMonsterCollision();

       sprite.rotate(2);
	   spriteBig.rotate(-2);

	}


	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
		shapeRenderer.dispose();
		batchRed.dispose();
		music.dispose();

	}

	@Override
	public boolean keyDown(int keycode) {
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		if(playerMovementOn) {
			PlayerDirectionCommandStore pacdisto = new PlayerDirectionCommandStore(character);}
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(float amountX, float amountY) {
		return false;
	}
}
