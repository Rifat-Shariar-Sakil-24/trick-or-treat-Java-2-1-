package com.mygdx.game.monsterModes.decidingModesForAllMonsters;

import com.mygdx.game.TheLastLife;
import com.mygdx.game.monsterModes.decidingModesForAllMonsters.decidingModesForCyanMonster.DecidingModesForCyanMonster;
import com.mygdx.game.monsterModes.decidingModesForAllMonsters.decidingModesForPinkMonster.DecidingModesForPinkMonster;
import com.mygdx.game.monsterModes.decidingModesForAllMonsters.decidingModesForRedMonster.DecidingModesForRedMonster;

public class DecidingModesForAllMonsters extends TheLastLife {
    public DecidingModesForAllMonsters()
    {
        DecidingModesForRedMonster decidingModesForRedMonster = new DecidingModesForRedMonster();
        DecidingModesForPinkMonster decidingModesForPinkMonster = new DecidingModesForPinkMonster();
        DecidingModesForCyanMonster decidingModesForCyanMonster = new DecidingModesForCyanMonster();
    }
}
